############################################################
# This file is imported from a different project.
# DO NOT make modifications in this repo.
# File a patch instead and assign it to Ryan Davis
############################################################

require 'minitest/unit'
require 'minitest/spec'
require 'minitest/mock'

MiniTest::Unit.autorun
