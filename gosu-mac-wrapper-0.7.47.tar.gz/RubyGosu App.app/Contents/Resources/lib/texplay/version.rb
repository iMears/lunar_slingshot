module TexPlay
  VERSION = "0.3.5"
end
